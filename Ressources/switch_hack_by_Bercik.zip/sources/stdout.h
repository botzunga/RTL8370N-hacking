#ifndef _STDOUT_H  // B: for no multi added header files
#define _STDOUT_H  //

void stdoutInit(uint8_t ubr);	  // B: int -> uint8_t
void uartSend(uint8_t data);	  // B: sends one char without "printf"
void uartSendS(char *s);		  // B: sends string without "printf"
void uartSends_P(const char *s);  // B: sends string_P without "printf"
char uartGet(void);				  // B: receive char without "printf"

#endif			   // ifndef _STDOUT_H
