/* Firmware to manage the 'hidden' functions of a RTL8366CB GBit switch.
(C) 2010 Jeroen Domburg (jeroen AT spritesmods.com)
(C) 2014 Bercik (ro_beri AT gazeta.pl)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
	    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
			    
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

//#include <stdio.h>  // B: not needed
#include "menu.h"
#include "stdout.h"   // B: added header file for uart_send

static char *getSubStr(PGM_P menuString, uint8_t item, char *dst, void (getData)(uint8_t menuItem, uint8_t no, char* buff))	// B: 3x int -> uint8_t
{
	uint8_t pctPos = 0, i = 0, j = 0, p = 0; 														// B : 2x int -> uint8_t
	char pctBuff[64];
	//Go to start of correct item
	while (p != item)
	{
		i++;
		while (pgm_read_byte(menuString + i) != 0 && pgm_read_byte(menuString + i) != '\n') i++;
		p++;
	}
	if (pgm_read_byte(menuString + i) == 0) return 0;
	if (item != 0) i++;
	//Ok, i is now at the start of the item. Copy to dst, expanding %s if necessary.
	while (pgm_read_byte(menuString + i) != 0 && pgm_read_byte(menuString + i) != '\n')
	{
		char c = pgm_read_byte(menuString + i);
		if (c == '%' && getData != 0)
		{
			//Do % expansion
			getData(item, pctPos, pctBuff);
			uint8_t x = 0;																			// B : int -> uint8_t
			while (pctBuff[x] != 0) { dst[j] = pctBuff[x]; j++; x++; }
			pctPos++;
		}
		else { dst[j] = c; j++; }
		i++;
	}
	//Zero-terminate
	dst[j] = 0;
	return dst;
}
static void menuDraw(PGM_P menuString, void (getData)(uint8_t menuItem, uint8_t no, char* buff))	// B: 2x int -> uint8_t
{
	char buff[80]; uint8_t i; char *itemTxt;														// B : int -> uint8_t
	//ToDo: Make prettier with ansi-chars etc
	uartSends_P(PSTR(" +++ ")); uartSendS(getSubStr(menuString, 0, buff, getData)); uartSends_P(PSTR(" +++\n"));
	i = 1;
	do
	{
		itemTxt = getSubStr(menuString, i, buff, getData);
		if (itemTxt != 0) { uartSend(i + '0'); uartSends_P(PSTR(". ")); uartSendS(itemTxt); uartSend('\n'); }
		i++;
		if (i == 20) return;
	}
	while (itemTxt != 0);
	uartSends_P(PSTR("0. Back\n"));
}
int menuShow(PGM_P menuString, void (getData)(uint8_t menuItem, uint8_t no, char* buff))			// B: 2x int -> uint8_t
{
	menuDraw(menuString, getData); char c = 0;

	do
		c = uartGet();
	while (c < '1' && c > '9');

	return c - '1' + 1;
}
