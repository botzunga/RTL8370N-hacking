/* Firmware to manage the 'hidden' functions of a RTL8366CB GBit switch.
(C) 2010 Jeroen Domburg (jeroen AT spritesmods.com)
(C) 2014 Bercik (ro_beri AT gazeta.pl)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
	    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
			    
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

//#define F_CPU 6000000       // B: not needed on Eclipse IDE
#include <avr/io.h>
#include <avr/pgmspace.h>
//#include <avr/interrupt.h>  // B: not needed header file
#include <avr/eeprom.h>
#include <util/delay.h>
//#include <stdio.h>          // B: not needed when using strCopy
//#include <string.h>         // B: not needed when using strCopy
#include "stdout.h"
#include "menu.h"
#include "io.h"

// B: ------------------- Realtek registers ------------------------------------
#if CHIP == 1								// B: definition for Realtek chip are in io.h
	#define RTL_GENCTL					   0x00

	#define RTL_PORTSTATUS_BASE 		   0x14
	#define RTL_PORTSTATUS_LINKMASK		   0x10
	#define RTL_PORTSTATUS_SPEEDMASK	   0x03
	#define RTL_PORTSTATUS_DUPLEXMASK	   0x04

	#define RTL_VLANTABLE_READBASE		 0x018c
	#define RTL_VLANTABLE_WRITEBASE		 0x0185
	#define RTL_VLANTABLE_WRITEVID_BEF_R 0x0185
	#define RTL_VLANTABLE_WRITEVID_BEF_W 0x0185
	#define RTL_VLANTABLE_ACCESSCTL		 0x0180
	#define RTL_VLANTABLE_DO_READ		 0x0e01
	#define RTL_VLANTABLE_DO_WRITE		 0x0f01

	#define RTL_VLANCTL_BASE			   0x63 //Set to unity on vlan enable: port1=member0, port2=member1 etc
	#define RTL_MEMCONF_BASE			   0x20 //Member config

	#define RTL_ENABLE_VLAN				 0x6000 // B: RTL8366RB_SGCR_EN_VLAN [BIT(13)] and [RTL8366RB_SGCR_EN_VLAN_4KTB BIT(14)]
	#define RTL_RESET_CTRL_REG			 0x0100 // B: RTL8366RB_RESET_CTRL_REG
	#define RTL_CHIP_NAME_REG			 0x0509 // B: Read Realtek chip name
	#define RTL_CHIP_VERSION_REG		 0x050a // B: Read Realtek chip version
	#define RTL_INGRESS_REG				 0x037f // B: Ingress function reg
	#define RTL_INGRESS_VALUE			   0x3f // B: Ingress function value
	#define RTL_PORTVID_MUL				      3 // B: Port vid register place shift
	#define RTL_PORTSETTING_SHIFT		   	  1 // B: Port setting shift
#elif CHIP == 2
	#define RTL_GENCTL					 0x07a8

	#define RTL_PORTSTATUS_BASE 		 0x1352
	#define RTL_PORTSTATUS_LINKMASK		   0x10 // B: the same as BIT(4) and RTL8367(B)
	#define RTL_PORTSTATUS_SPEEDMASK	   0x03 // B: the same as RTL8366RB
	#define RTL_PORTSTATUS_DUPLEXMASK	   0x04 // B: the same as BIT(2) and RTL8367(B)

	#define RTL_VLANTABLE_READBASE		 0x0503
	#define RTL_VLANTABLE_WRITEBASE		 0x0503
	#define RTL_VLANTABLE_WRITEVID_BEF_R 0x0501
	#define RTL_VLANTABLE_WRITEVID_BEF_W 0x0501
	#define RTL_VLANTABLE_ACCESSCTL		 0x0500
	#define RTL_VLANTABLE_DO_READ		   0x03
	#define RTL_VLANTABLE_DO_WRITE		   0x13

	#define RTL_VLANCTL_BASE			 0x0700
	#define RTL_MEMCONF_BASE			 0x072b

	#define RTL_ENABLE_VLAN				   0x01
	#define RTL_RESET_CTRL_REG			 0x1322
	#define RTL_CHIP_NAME_REG			 0x13c0
	#define RTL_CHIP_VERSION_REG		 0x13c1
	#define RTL_INGRESS_REG				 0x07a9
	#define RTL_INGRESS_VALUE			 0x03ff
	#define RTL_PORTVID_MUL				      4
	#define RTL_PORTSETTING_SHIFT		      0
#elif CHIP == 3
	#define RTL_GENCTL					 0x07a8

	#define RTL_PORTSTATUS_BASE 		 0x1352
	#define RTL_PORTSTATUS_LINKMASK		   0x10 // B: the same as BIT(4) and RTL8367(B)
	#define RTL_PORTSTATUS_SPEEDMASK	   0x03 // B: the same as RTL8366RB
	#define RTL_PORTSTATUS_DUPLEXMASK	   0x04 // B: the same as BIT(2) and RTL8367(B)

	#define RTL_VLANTABLE_READBASE	  	 0x0520
	#define RTL_VLANTABLE_WRITEBASE		 0x0510
	#define RTL_VLANTABLE_WRITEVID_BEF_R 0x0501
	#define RTL_VLANTABLE_WRITEVID_BEF_W 0x0501
	#define RTL_VLANTABLE_ACCESSCTL		 0x0500
	#define RTL_VLANTABLE_DO_READ		   0x03
	#define RTL_VLANTABLE_DO_WRITE		   0x0b

	#define RTL_VLANCTL_BASE			 0x0700
	#define RTL_MEMCONF_BASE			 0x072b

	#define RTL_ENABLE_VLAN				   0x01
	#define RTL_RESET_CTRL_REG			 0x1322
	#define RTL_CHIP_NAME_REG			 0x1301
	#define RTL_CHIP_VERSION_REG		 0x1300
	#define RTL_INGRESS_REG				 0x07a9
	#define RTL_INGRESS_VALUE			   0xff
	#define RTL_PORTVID_MUL				      4
	#define RTL_PORTSETTING_SHIFT			  0
#endif
// B: ------------------- membership definition --------------------------------
/* Membership is... weird.
Port status		output
T				Tagged as vlan x
T+M				Untagged
M				None
-				None
*/
#define VLAN_NONE		0
#define VLAN_TAGGED		1
#define VLAN_UNTAGGED	2
// B: ------------------- function definitions ---------------------------------
void int2num(int data, uint8_t radix);
void int2hex(int data, uint8_t radix);
void strCopy(char *d, const char *s);
void setIngress(void);
unsigned int getPortVid(uint8_t port);
void setPortVid(uint8_t port, int vid);
void setVlanMembership(uint8_t port, char type, int vid);
void dumpVlanInfo(void);
int gethex(void);
int getdec(void);
void waitkey(void);
void dumpEeprom(void);
void dumpRtlRegisters(void);
char getVlanEnabled(void);
void showPortSettings(uint8_t port);
void dumpAvrEeprom(void);
void saveConfig(void);
void loadConfig(void);
void resetVlans(void);
void generalMenuCallback(uint8_t menuItem, uint8_t no, char *buff);
void portMenuCallback(uint8_t menuItem, uint8_t no, char *buff);
int main(void);
// B: ------------------- globals ----------------------------------------------
char cmd_num[5];												// B: max position is 4 /4+1/
#define currentPort GPIOR0 // uint8_t currentPort;				// B: int -> uint8_t, currentPort value stored in GPIOR0
// B: ------------------- function declaration ---------------------------------
void int2num(int data, uint8_t radix)							// B: convert int to char[radix] decimal
{
	cmd_num[radix]='\0';
	for(int i = (radix-1); i >= 0; data /= 10, i--) cmd_num[i] = (data % 10) +'0';

	if (cmd_num[0] != '0') {}
	else
	{
		cmd_num[0]=' ';
		if (cmd_num[1] != '0') {}
		else
		{
			cmd_num[1]=' ';
			if (cmd_num[2] !='0') {}
			else cmd_num[2]=' ';
		}
	}
}
void int2hex(int data, uint8_t radix)							// B: convert int to char[radix] hex
{
	char cmd_num[radix+1]; cmd_num[radix]='\0'; 				// 4 3 2
	for (int i = 0; i < radix; i++)             				//12 8 4
	{                                           				// 8 4 0
		uint8_t y = ((radix-(i+1))*4);          				// 4 0 0
		cmd_num[i] = (data>>y) & 0xf;         					// 0 0 0
		if (cmd_num[i] <= 9) cmd_num[i] += '0';
		else                 cmd_num[i] += 'a' - 10;
	}
	uartSendS(cmd_num);
}
void strCopy(char *d, const char *s)							// B: copy string d -> s
{
	uint8_t x;
	for(x = 0; s[x] != '\0'; x++) d[x] = s[x];
	d[x] = '\0';
}
void setIngress()												// B: sets ingress  for "bad vid member"
{
	rtlWrite(RTL_INGRESS_REG, RTL_INGRESS_VALUE);
}
unsigned int getPortVid(uint8_t port)							// B: int -> uint8_t
{
	return rtlRead(RTL_MEMCONF_BASE + (RTL_PORTVID_MUL * port));
}
void setPortVid(uint8_t port, int vid)							// B: int -> uint8_t
{
	rtlWrite(RTL_MEMCONF_BASE + (RTL_PORTVID_MUL * port), vid);
}
void setVlanMembership(uint8_t port, char type, int vid)		// B: int -> uint8_t, char -> void, removed ints for using fids
{
	unsigned int r1;

	#if   CHIP == 1
		unsigned int r2;
	#elif CHIP == 2
		unsigned int r3;
		unsigned int r4;
	#elif CHIP == 3
	#endif

	//unsigned int mask = (1<<port) | (1<<(port + 8));			// B: not used in return
	rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_R, vid);
	rtlWrite(RTL_VLANTABLE_ACCESSCTL, RTL_VLANTABLE_DO_READ);

	r1 = rtlRead(RTL_VLANTABLE_READBASE);

	#if   CHIP == 1												// B: 66RB -> R1, R2, (R3)
		r2 = rtlRead(RTL_VLANTABLE_READBASE + 1);

		r2 &= ~((1<<port) | (1<<(port + 8)));                   // B: part A
		if (type != VLAN_NONE)     r2 |= (1<<port);             // B: part B
		if (type == VLAN_UNTAGGED) r2 |= (1<<(port + 8));       // B: part C
	#elif CHIP == 2												// B: 67   -> R1, (R2), R3, R4
		r3 = rtlRead(RTL_VLANTABLE_READBASE + 2);
		r4 = rtlRead(RTL_VLANTABLE_READBASE + 3);

		r1 &= ~(1<<port);										// B: part A
		if (port < 2) r3 &= ~(1<<(port + 14));					// B: part A
		if (port > 1) r4 &= ~(1<<(port -  2));					// B: part A
		if (type != VLAN_NONE)     r1 |= (1<<port);				// B: part B
		if (type == VLAN_UNTAGGED)								// B: part C
		{														// B: part C
			if (port < 2) r3 |= (1<<(port + 14));				// B: part C
			if (port > 1) r4 |= (1<<(port -  2));				// B: part C
		}														// B: part C
	#elif CHIP == 3												// B: 67B  -> R1, (R2)
		r1 &= ~((1<<port) | (1<<(port + 8)));                   // B: part A
		if (type != VLAN_NONE)     r1 |= (1<<port);             // B: part B
		if (type == VLAN_UNTAGGED) r1 |= (1<<(port + 8));       // B: part C
	#endif

	rtlWrite(RTL_VLANTABLE_WRITEBASE,     r1);

	#if   CHIP == 1
		rtlWrite(RTL_VLANTABLE_WRITEBASE + 1, r2);
	#elif CHIP == 2
		rtlWrite(RTL_VLANTABLE_WRITEBASE + 2, r3);
		rtlWrite(RTL_VLANTABLE_WRITEBASE + 3, r4);

		rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_W, vid);
	#elif CHIP == 3
		rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_W, vid & 0x3fff);
	#endif

	rtlWrite(RTL_VLANTABLE_ACCESSCTL, RTL_VLANTABLE_DO_WRITE);
	//return r2 & mask ? 1:0;									// B: return is not used
}
void dumpVlanInfo(void)
{
	uartSends_P(PSTR("Untagged incoming packets will get the following VID tag:\n"));

	#if MIN_SHOW_VID
		unsigned int vid_table[PORT_COUNT];
	#endif

	for (uint8_t x = 0; x < PORT_COUNT; x++)					// B: int -> uint8_t
	{
		#if MIN_SHOW_VID
			vid_table[x] = getPortVid(x);
		#endif

		uartSends_P(PSTR("Port ")); uartSend(x + 1 +'0'); uartSends_P(PSTR(": VID "));

		#if MIN_SHOW_VID
			int2num(vid_table[x], 4);
		#else
			int2num(getPortVid(x), 4);
		#endif

		uartSendS(cmd_num); uartSend('\n');
	}

	#if MIN_SHOW_VID
		uartSends_P(PSTR("Vlans defined and ports in them: (U=Untagged, T=Tagged)\n"));
	#else
		uartSends_P(PSTR("Vlans defined and ports in them: (U=Untagged, T=Tagged)(takes a while)\n"));
	#endif

	#if   PORT_COUNT == 5
		uartSends_P(PSTR("VID   p1 p2 p3 p4 p5\n"));
	#elif PORT_COUNT == 8
		uartSends_P(PSTR("VID   p1 p2 p3 p4 p5 p6 p7 p8\n"));
	#endif

	for (unsigned int vid = 0; vid < 4096; vid++)
	{
		#if MIN_SHOW_VID
			#if   PORT_COUNT == 5
				if (vid == vid_table[0] || vid == vid_table[1] || vid == vid_table[2] || vid == vid_table[3] || vid == vid_table[4])
			#elif PORT_COUNT == 8
				if (vid == vid_table[0] || vid == vid_table[1] || vid == vid_table[2] || vid == vid_table[3] || vid == vid_table[4] || vid == vid_table[5] || vid == vid_table[6] || vid == vid_table[7])
			#endif
		{
		#endif

			#if   CHIP == 1
				unsigned int r2;
			#elif CHIP == 2
				unsigned int r1, r3, r4;
			#elif CHIP == 3
				unsigned int r1;
			#endif

			rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_R, vid);
			rtlWrite(RTL_VLANTABLE_ACCESSCTL, RTL_VLANTABLE_DO_READ);

			#if   CHIP == 1
				r2 = rtlRead(RTL_VLANTABLE_READBASE + 1);
			#elif CHIP == 2
				r1 = rtlRead(RTL_VLANTABLE_READBASE);
				r3 = rtlRead(RTL_VLANTABLE_READBASE + 2);
				r4 = rtlRead(RTL_VLANTABLE_READBASE + 3);
			#elif CHIP == 3
				r1 = rtlRead(RTL_VLANTABLE_READBASE);
			#endif

			#if   CHIP == 1
			if (r2 != 0)
			#elif CHIP == 2 || CHIP == 3
			if (r1 != 0)
			#endif
			{
				int2num(vid, 4); uartSendS(cmd_num); uartSendS(": ");
				for (uint8_t port = 0; port < PORT_COUNT; port++)  // B: int -> uint8_t
				{
					int mask = (1<<port);

					#if   CHIP == 1
					if (r2 & mask)
					#elif CHIP == 2 || CHIP == 3
					if (r1 & mask)
					#endif
					{
						#if   CHIP == 1
							if ((r2>>8) & mask)      		        uartSend('U'); else uartSend('T');
						#elif CHIP == 2
							if (port < 2) {if (r3 & 1<<(port + 14)) uartSend('U'); else uartSend('T');}
							if (port > 1) {if (r4 & 1<<(port -  2)) uartSend('U'); else uartSend('T');}
						#elif CHIP == 3
							if ((r1>>8) & mask)      		        uartSend('U'); else uartSend('T');
						#endif
					}
					else uartSend(' ');
					uartSendS("  ");
				}
				uartSend('\n');
			}
		#if MIN_SHOW_VID
		}
		#endif
	}
}
int gethex(void)
{
	char c, first = 1; int amt = 0;
	while (1)
	{
		c = uartGet();
		if      (c >= '0' && c <= '9') { amt <<= 4; amt += c - '0'; }
		else if (c >= 'A' && c <= 'F') { amt <<= 4; amt += c - 'A' + 10; }
		else if (c >= 'a' && c <= 'f') { amt <<= 4; amt += c - 'a' + 10; }
		else
		{
			if (first) return -1;
			uartSend('\n');
			return amt;
		}
		uartSend(c); first = 0;
	}
	return 0xffff; 												// B: fixes for warning of missing return
}
int getdec(void)
{
	char c, first = 1; int amt = 0;
	while (1)
	{
		c = uartGet();
		if (c >= '0' && c <= '9') { amt = amt * 10; amt += c - '0'; }
		else
		{
			if (first) return -1;
			uartSend('\n');
			return amt;
		}
		uartSend(c); first = 0;
	}
	return 0xffff; 												// B: fixes for warning of missing return
}
void waitkey(void)
{
	uartSends_P(PSTR("Press any key to continue.\n")); uartGet();
}
void dumpEeprom(void)
{
	unsigned int x, y;
	for (y = 0; y < 0x100; y += 16)								// B: 256 -> 0x100
	{
		int2hex(y, 2); uartSendS(": ");
		for (x = 0; x < 16; x++)
		{
			int2hex(eepromRead(y + x), 2); uartSend(' ');
		}
		uartSend('\n');
	}
	waitkey();
}
void dumpRtlRegisters(void)
{
	unsigned int x, y, addrL, addrH;                            // B: added addrL and addrH
	uartSends_P(PSTR("Select address range (hex):\n"));			// B:
	uartSends_P(PSTR("Low: "));  addrL = gethex(); 				// B: for selection range
	uartSends_P(PSTR("High: ")); addrH = gethex(); 				// B: registers to dump
	for (y = addrL - (addrL % 8); y < addrH; y += 8)
	{
		int2hex(y, 4); uartSendS(": ");
		for (x = 0; x < 8; x++)
		{
			int2hex(rtlRead(y + x), 4); uartSend(' ');
		}
		uartSend('\n');
	}
	waitkey();
}
char getVlanEnabled(void)										// B: added "(void)"
{
	int s = rtlRead(RTL_GENCTL);
	if (s & (RTL_ENABLE_VLAN)) return 1;						// B: 0x6000 -> RTL_ENABLE_VLAN
	else                       return 0;
}
void setVlanEnabled(char ena)
{
	int s = rtlRead(RTL_GENCTL);
	if (ena) s |= RTL_ENABLE_VLAN;								// B: 0x6000 -> RTL_ENABLE_VLAN
	else     s &= ~RTL_ENABLE_VLAN;								// B: 0x6000 -> RTL_ENABLE_VLAN
	rtlWrite(RTL_GENCTL, s);
	#if   CHIP == 1
		//Hack: mapping from ports to member-id-entries. Somehow, the device doesn't set this itself.
		rtlWrite(RTL_VLANCTL_BASE,     0x3210);
		rtlWrite(RTL_VLANCTL_BASE + 1, 0x7654);
	#elif CHIP == 2 || CHIP == 3
		rtlWrite(RTL_VLANCTL_BASE,     0x0100);
		rtlWrite(RTL_VLANCTL_BASE + 1, 0x0302);
		rtlWrite(RTL_VLANCTL_BASE + 2, 0x0504);
		rtlWrite(RTL_VLANCTL_BASE + 3, 0x0706);
	for (uint8_t i = 0; i < PORT_COUNT; i++) rtlWrite(0x000e + (0x20 * i), rtlRead(0x000e + (0x20 * i)) & 0xffcf);
	#endif
}
void showPortSettings(uint8_t port)								// B: int -> uint8_t
{
	int s = rtlRead(RTL_PORTSTATUS_BASE + (port>>RTL_PORTSETTING_SHIFT));
	#if CHIP == 1
		if (port & 1) s >>= 8;
		else s &= 0xff;
	#endif
	uartSends_P(PSTR("Port ")); uartSend(port + 1 + '0'); uartSendS((": "));
	if (s & RTL_PORTSTATUS_LINKMASK)
	{
		uartSends_P(PSTR("U ")); // B: "link up: "
		if ((s & RTL_PORTSTATUS_SPEEDMASK) == 0) uartSends_P(PSTR(" 10 MiB")); // B: "10MBit "
		if ((s & RTL_PORTSTATUS_SPEEDMASK) == 1) uartSends_P(PSTR("100 MiB")); // B: "100MBit "
		if ((s & RTL_PORTSTATUS_SPEEDMASK) == 2) uartSends_P(PSTR("  1 GiB")); // B: "1GBit "
		if (s & RTL_PORTSTATUS_DUPLEXMASK) uartSends_P(PSTR(" FD")); // B: FD <-> HD. "FD"
		else                               uartSends_P(PSTR(" HD")); // B: FD <-> HD. "FD"
	}
	else uartSend('D'); // B: "link down: "
	uartSend('\n');
}
void dumpAvrEeprom(void)
{
	unsigned int x, y;
	for (y = 0; y < 0x100; y += 8)
	{
		int2hex(y, 2); uartSendS(": ");
		for (x = 0; x < 8; x++)
		{
			int2hex(eeprom_read_word((const uint16_t *)((y + x) * 2)), 4); uartSend(' ');
		}
		uartSend('\n');
	}
	waitkey();
}
void saveConfig(void) //Save the config to the internal EEPROM.	// B: _write_ -> _update
{
	unsigned int* p; p = 0;

	#if MIN_SHOW_VID
		uartSends_P(PSTR("Saving...\n"));
	#else
		uartSends_P(PSTR("Saving, this takes a while...\n"));
	#endif

	eeprom_update_word(p++, (0xa5<<8) + getVlanEnabled());

	#if MIN_SHOW_VID
		unsigned int vid_table[PORT_COUNT];
		for (uint8_t x = 0; x < PORT_COUNT; x++) { vid_table[x] = getPortVid(x); eeprom_update_word(p++, vid_table[x]); }

		for (unsigned int vid = 0; vid < 4096; vid++)
	#else
		for (uint8_t x = 0; x < PORT_COUNT; x++)   eeprom_update_word(p++, getPortVid(x)); // B: int -> uint8_t

		for (unsigned int vid = 0; vid < 4096 && (int)p < 511; vid++)
	#endif
	{

		#if MIN_SHOW_VID
			#if PORT_COUNT == 5
				if (vid == vid_table[0] || vid == vid_table[1] || vid == vid_table[2] || vid == vid_table[3] || vid == vid_table[4])
			#elif PORT_COUNT == 8
				if (vid == vid_table[0] || vid == vid_table[1] || vid == vid_table[2] || vid == vid_table[3] || vid == vid_table[4] || vid == vid_table[5] || vid == vid_table[6] || vid == vid_table[7])
			#endif
		{
		#endif

			#if   CHIP == 1
				unsigned int r2;
			#elif CHIP == 2
				unsigned int r1, r3, r4;
			#elif CHIP == 3
				unsigned int r1;
			#endif

			rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_R, vid);
			rtlWrite(RTL_VLANTABLE_ACCESSCTL, RTL_VLANTABLE_DO_READ);

			#if   CHIP == 1
				r2 = rtlRead(RTL_VLANTABLE_READBASE + 1);
			#elif CHIP == 2
				r1 = rtlRead(RTL_VLANTABLE_READBASE);
				r3 = rtlRead(RTL_VLANTABLE_READBASE + 2);
				r4 = rtlRead(RTL_VLANTABLE_READBASE + 3);
			#elif CHIP == 3
				r1 = rtlRead(RTL_VLANTABLE_READBASE);
			#endif

			#if CHIP == 1
				if (r2 != 0)
			#elif CHIP == 2 || CHIP == 3
				if (r1 != 0)
			#endif
			{
				eeprom_update_word(p++, vid);

				#if   CHIP == 1
					eeprom_update_word(p++, r2);
				#elif CHIP == 2
					eeprom_update_word(p++, (r1 & 0xff) | ((r3>>6) & 0x0300) | ((r4<<10) & 0xfc00));
				#elif CHIP == 3
					eeprom_update_word(p++, r1);
				#endif
			}
		}
	#if MIN_SHOW_VID
	}
	#endif
	eeprom_update_word(p++, 0xffff);

	#if MIN_SHOW_VID
		uartSends_P(PSTR("Config saved, "));
		int2num((int)p, 2); uartSendS(cmd_num); uartSends_P(PSTR(" bytes used.\n"));
	#else
		if ((int)p >= 511) uartSends_P(PSTR("Couldn't save config: too many vlans!\n"));
		else
		{
			uartSends_P(PSTR("Config saved, "));
			int2num((int)p, ((int)p < 100 ? 2 : 3)); uartSendS(cmd_num); uartSends_P(PSTR(" bytes used.\n"));
		}
	#endif
}
void loadConfig(void) //Load the config from the internal EEPROM.//B: removed ints for using fids
{
	unsigned int *p; p = 0;
	unsigned int vid, n;

	#if   CHIP == 1
		unsigned int r2;
	#elif CHIP == 2
		unsigned int r134;
	#elif CHIP == 3
		unsigned int r1;
	#endif

	n = eeprom_read_word(p++);
	if ((n>>8) != 0xa5) uartSends_P(PSTR("Invalid config in eeprom, not loaded.\n"));
	else
	{
		setVlanEnabled(n & 0xff);
		for (uint8_t x = 0; x < PORT_COUNT; x++) setPortVid(x, eeprom_read_word(p++));
		while ((vid = eeprom_read_word(p++)) != 0xffff)
		{
			#if   CHIP == 1
				r2 = eeprom_read_word(p++);

				rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_W, vid); // B: write vid
				rtlWrite(RTL_VLANTABLE_WRITEBASE + 1, r2);   // B: write member and untag
			#elif CHIP == 2
				r134 = eeprom_read_word(p++);

				rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_W, vid);
				rtlWrite(RTL_VLANTABLE_WRITEBASE,      r134      &   0xff);
				rtlWrite(RTL_VLANTABLE_WRITEBASE + 2, (r134<< 6) & 0xc000);
				rtlWrite(RTL_VLANTABLE_WRITEBASE + 3, (r134>>10) &   0x3f);
			#elif CHIP == 3
				r1 = eeprom_read_word(p++);

				rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_W, vid);
				rtlWrite(RTL_VLANTABLE_WRITEBASE,     r1);
			#endif
			rtlWrite(RTL_VLANTABLE_ACCESSCTL, RTL_VLANTABLE_DO_WRITE);
		}
	}
}
void resetVlans(void)											// B: removed ints for using fids
{
	//Reset chip and wait...
	rtlWrite(RTL_RESET_CTRL_REG, 1);				   			// B: 0x0100 -> RTL_RESET_CTRL_REG
	_delay_ms(1000); //needs 10 secs?
	setVlanEnabled(1);

	for (uint8_t x = 0; x < PORT_COUNT; x++) setPortVid(x, 1);  // B: int -> uint8_t
	rtlWrite(RTL_VLANTABLE_WRITEVID_BEF_W, 1);

	#if   CHIP == 1
		rtlWrite(RTL_VLANTABLE_WRITEBASE + 1, 0xffff);
	#elif CHIP == 2
		rtlWrite(RTL_VLANTABLE_WRITEBASE,     0xffff);
		rtlWrite(RTL_VLANTABLE_WRITEBASE + 2, 0xc000);
		rtlWrite(RTL_VLANTABLE_WRITEBASE + 3, 0x3fff);
	#elif CHIP == 3
		rtlWrite(RTL_VLANTABLE_WRITEBASE,     0xffff);
	#endif

	rtlWrite(RTL_VLANTABLE_ACCESSCTL, RTL_VLANTABLE_DO_WRITE);
}
const char mainMenu[] PROGMEM="Main menu\n" \
		"General settings\n" \
		"Per-port settings\n" \
		"Info\n" \
		"Debug\n" \
		"Save config\n" \
		"Load config\n" \
		"Show Realtek chip name";								// B: added to read Realtek chip name
const char generalMenu[] PROGMEM="General menu\n" \
		"Toggle VLAN support (is %)\n"
		"Reset to sensible VLAN settings";
void generalMenuCallback(uint8_t menuItem, uint8_t no, char *buff) 	// B: 2x int -> uint8_t
{
	if (getVlanEnabled()) strCopy(buff, "Enabled");
	else                  strCopy(buff, "Disabled");
}
const char debugMenu[] PROGMEM="Debug menu\n" \
		"Dump 24c02 (in bytes)\n" \
		"Dump RTL registers (in words)\n" \
		"Reset chip\n" \
		"Write to 24c02\n" \
		"Set register\n" \
		"Dump AVR EEPROM (in words)";							// B: added "in bytes", "in words"
const char infoMenu[] PROGMEM="Info\n" \
		"Port connections\n" \
		"VLAN config";
const char portMenu[] PROGMEM="Port settings for port %\n" \
		"Connection info\n" \
		"Add to vlan, untagged output\n" \
		"Add to vlan, tagged output\n" \
		"Remove from vlan\n" \
		"Change VLAN untagged packets go to (is %)\n" \
		"View current vlan setup";
void portMenuCallback(uint8_t menuItem, uint8_t no, char *buff)	// B: 2x int -> uint8_t
{
	if (menuItem == 0) int2num(currentPort + 1, 1);
	if (menuItem == 5)
	{
		unsigned int vid = getPortVid(currentPort);
		int2num(vid, (vid < 1000 ? (vid < 100 ? (vid < 10 ? 1 : 2) : 3) : 4));
	}
	strCopy(buff, cmd_num);
}
int main() //Main routine
{
	// B: switching off not used ATMega components
	PRR |= _BV(PRADC) | _BV(PRSPI) | _BV(PRTIM1) | _BV(PRTIM0) | _BV(PRTIM2) | _BV(PRTWI);

	uint8_t choice;												// B: int -> uint8_t
	stdoutInit(25);												// B: 19200@8MHz internal RC
	initIo();
	for (uint8_t x = 4; x > 0; x--)								// B: int -> uint8_t,  "..." -> countdown
	{
		 uartSend(' '); uartSend(x +'0'); _delay_ms(500); uartSend(0x08);
	}
	uartSend('\n');
	loadConfig();
	setIngress();												// B: switch on ingress
	while(1)
	{
		choice = menuShow(mainMenu, 0);
		if      (choice == 1)	//General menu
		{
			while((choice = menuShow(generalMenu, generalMenuCallback)) != 0)
			{
				if      (choice == 1) setVlanEnabled(!getVlanEnabled());
				else if (choice == 2)
				{
					uartSends_P(PSTR("This will reset your current config. You sure? (y/n)\n"));
					if (uartGet() == 'y') { resetVlans(); setIngress(); } // B: switch on ingress after reset
				}
			}
		}
		else if (choice == 2)	//Per-port menu
		{
			uint8_t port = 0; 									// B: int -> uint8_t

			#if   PORT_COUNT == 5
				uartSends_P(PSTR("Which port? (1-5) "));
			#elif PORT_COUNT == 8
				uartSends_P(PSTR("Which port? (1-8) "));
			#endif

			port = getdec() - 1; currentPort = port;
			while(port >= 0 && port < PORT_COUNT && (choice = menuShow(portMenu, portMenuCallback)) != 0) // B: /"... port < 5 && (choice = ..."/
			{
				if      (choice == 1)
				{
					showPortSettings(port); waitkey();
				}
				else if (choice == 2 || choice == 3 || choice == 4)
				{
					uartSends_P(PSTR("Which VID? (<4097) ")); 	// B: /"Which VID? "/
					int vid = getdec();
					if (vid > 0 && vid < 4097) 					// B: block for vid > 4096 or vid = 0
					{
						if      (choice == 2)
						{
							setVlanMembership(port, VLAN_UNTAGGED, vid);
							uartSends_P(PSTR("Port added to VLAN, outputs untagged data.\n"));
						}
						else if (choice == 3)
						{
							setVlanMembership(port, VLAN_TAGGED, vid);
							uartSends_P(PSTR("Port added to VLAN, outputs tagged data.\n"));
						}
						else if (choice == 4)
						{
							setVlanMembership(port, VLAN_NONE, vid);
							uartSends_P(PSTR("Port removed\n"));
						}
						waitkey();
					}
				}
				else if (choice == 5)
				{
					uartSends_P(PSTR("Tag with which VID? (<4097) "));	// B: /"Tag with which VID? "/
					int vid = getdec();
					if (vid > 0 && vid < 4097)							// B: block for vid > 4096 or vid = 0
					{
						#if MIN_SHOW_VID
							setVlanMembership(port, VLAN_NONE, getPortVid(port));
							setPortVid(port, vid);
							setVlanMembership(port, VLAN_UNTAGGED, vid);
						#else
							setPortVid(port, vid);
						#endif
					}
				}
				else if (choice == 6)
				{
					dumpVlanInfo(); waitkey();
				}
			}
		}
		else if (choice == 3)	//Info menu
		{
			while((choice = menuShow(infoMenu, 0)) != 0)
			{
				if      (choice == 1)
				{
					for (uint8_t x = 0; x < PORT_COUNT; x++) showPortSettings(x);	// B: int -> uint8_t
					waitkey();
				}
				else if (choice == 2)
				{
					if (!getVlanEnabled()) uartSends_P(PSTR("Vlans are disabled! Enable them first.\n"));
					else                   dumpVlanInfo();
					waitkey();
				}
			}
		}
		else if (choice == 4)	//Debug menu
		{
			while((choice = menuShow(debugMenu, 0)) != 0)
			{
				if      (choice == 1) dumpEeprom();
				else if (choice == 2) dumpRtlRegisters();
				else if (choice == 3)
				{
					rtlWrite(RTL_RESET_CTRL_REG, 1); 				// B: 0x0100 -> RTL_RESET_CTRL_REG
					_delay_ms(1000); setIngress(); //setIngress();
				}
				else if (choice == 4 || choice == 5)
				{
					int addr, data = 0;
					uartSends_P(PSTR("Address (hex)? ")); 			// B: /"Address? "/
					addr = gethex();
					do
					{
						int2hex(addr, 4); uartSendS("? "); data = gethex();
						if (choice == 4 && data != -1) eepromWrite(addr, data);
						if (choice == 5 && data != -1) rtlWrite(addr, data);
						addr++;
					}
					while (data != -1);
				}
				else if (choice == 6) dumpAvrEeprom();
			}
		}
		else if (choice == 5)	// B: Save config
		{
			saveConfig(); waitkey();
		}
		else if (choice == 6)	// B: Load config
		{
			loadConfig(); waitkey();
		}
		else if (choice == 7)										// B: Show Realtek chip name
		{
			unsigned int name_val = rtlRead(RTL_CHIP_NAME_REG);
			uartSends_P(PSTR("Name value is (hex): ")); int2hex(name_val, 4);
			#if   CHIP == 1
				if      (name_val == 0x5937) uartSends_P(PSTR(" Chip is: 'RTL8366RB'\n"));
			#elif CHIP == 2
				if      (name_val == 0x3670) uartSends_P(PSTR(" Chip is: 'RTL8367R'\n"));
				else if (name_val == 0x3671) uartSends_P(PSTR(" Chip is: 'RTL8367M'\n"));
			#elif CHIP == 3
				if      (name_val == 0x0000) uartSends_P(PSTR(" Chip is: 'RTL8367RB'\n"));
				else if (name_val == 0x0010) uartSends_P(PSTR(" Chip is: 'RTL8367R-VB'\n"));
			#endif
				else                         uartSends_P(PSTR(" Chip is: 'unknowkn'\n"));

			uartSends_P(PSTR("Version value is (hex): ")); int2hex(rtlRead(RTL_CHIP_VERSION_REG), 4); uartSend('\n');
			waitkey();
		}
	}
}
