/* Firmware to manage the 'hidden' functions of a RTL8366CB GBit switch.
(C) 2010 Jeroen Domburg (jeroen AT spritesmods.com)
(C) 2014 Bercik (ro_beri AT gazeta.pl)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
	    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
			    
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

//#define F_CPU 6000000		  // B: not needed on Eclipse IDE
#include <avr/io.h>
//#include <avr/interrupt.h>  // B: not needed in io.c
#include <util/delay.h>
//#include <util/twi.h>		  // B: not needed when not using TWI routine
#include "stdout.h"			  // B: added header file for uart_send
#include "io.h"

#define STR_CONCAT_PRIM(a, b) a ## b				// B: added for select SDA, SCL pins
#define STR_CONCAT(a, b) 	  STR_CONCAT_PRIM(a, b) // B: added for select SDA, SCL pins

#if   CHIP == 1 || CHIP == 3
#define I2CDELAY	5
#elif CHIP == 2
#define I2CDELAY	750
#endif

#define SCL_PORT	D                             // B: added for select SDA, SCL pins
#define SCL_PIN		7                             // B: added for select SDA, SCL pins

#define SDA_PORT	D							  // B: added for select SDA, SCL pins
#define SDA_PIN		5

#define EEPROM_READ_ADRESS0 0xa0
#define EEPROM_READ_ADRESS1 0xa1

#if   CHIP == 1									  // B: definition for Realtek chip are in io.h
#define RTL_READ_ADRESS     0xa9
#define RTL_WRITE_ADRESS    0xa8
#elif CHIP == 2 || CHIP == 3
#define RTL_READ_ADRESS     0xb9
#define RTL_WRITE_ADRESS    0xb8
#endif

#define SCL_PORT_OUT  STR_CONCAT(PORT, SCL_PORT)  // B: added for select SDA, SCL pins
#define SDA_PORT_OUT  STR_CONCAT(PORT, SDA_PORT)  // B: added for select SDA, SCL pins

#define SCL_PORT_DDR  STR_CONCAT(DDR, SCL_PORT)	  // B: added for select SDA, SCL pins
#define SDA_PORT_DDR  STR_CONCAT(DDR, SDA_PORT)	  // B: added for select SDA, SCL pins

#define SDA_PORT_PIN  STR_CONCAT(PIN, SDA_PORT)	  // B: added for select SDA, SCL pins

static void setScl(char val) //Hack-ish skeleton i2c routines, but these should be enough.
{
#if 0
	SCL_PORT_DDR |= (1<<SCL_PIN);              	  // B: SCL -> SCL_PIN, DDRC -> SCL_PORT_DDR
	if (val) SCL_PORT_OUT |= (1<<SCL_PIN);     	  // B: SCL -> SCL_PIN, PORTC -> SCL_PORT_OUT
	else     SCL_PORT_OUT &= ~(1<<SCL_PIN);    	  // B: SCL -> SCL_PIN, PORTC -> SCL_PORT_OUT
#else
	if (val) SCL_PORT_DDR &= ~(1<<SCL_PIN);    	  // B: SCL -> SCL_PIN, DDRC -> SCL_PORT_DDR
	else     SCL_PORT_DDR |= (1<<SCL_PIN);     	  // B: SCL -> SCL_PIN, DDRC -> SCL_PORT_DDR
#endif
	_delay_us(I2CDELAY);
}
static void setSda(char val)
{
	if (val) SDA_PORT_DDR &= ~(1<<SDA_PIN);		  // B: SDA -> SDA_PIN, DDRC -> SDA_PORT_DDR
	else     SDA_PORT_DDR |= (1<<SDA_PIN);		  // B: SDA -> SDA_PIN, DDRC -> SDA_PORT_DDR
	_delay_us(I2CDELAY);
}
static char getSda(void)
{
	_delay_us(I2CDELAY);
	if (SDA_PORT_PIN & (1<<SDA_PIN)) return 1;	  // B: SDA -> SDA_PIN, SDA_PORT_PIN
	else return 0;
}
static char i2cWrite(unsigned char data)
{
	char ack;
	for (char x = 0x80; x != 0; x >>= 1)
	{
		if (data & x) setSda(1);
		else          setSda(0);
		setScl(1); setScl(0);
	}
	//Get ack
	setSda(1); setScl(1); ack = !getSda(); setScl(0);
	return ack;
}
static unsigned char i2cRead(char ack)
{
	unsigned char data = 0;
	setSda(1);
	for (unsigned char x = 0x80; x != 0; x >>= 1)
	{
		setScl(1);
		if (getSda()) data |= x;
		setScl(0);
	}
	//Send ack
	setSda(!ack); setScl(1); setScl(0);
	return data;
}
static char i2cStart(char address)
{
	setScl(1); setSda(0); setScl(0);
	return i2cWrite(address);
}
static void i2cStop(void)
{
	setSda(0); setScl(1); setSda(1);
}
//Eeprom routines
unsigned char eepromRead(int adr)
{
	unsigned char r;
	if (!i2cStart(EEPROM_READ_ADRESS0)) uartSendS("No ack!"); //dummy write	// B: 0xA0 -> EEPROM_READ_ADRESS0
	i2cWrite(adr);
	i2cStart(EEPROM_READ_ADRESS1); //read									// B: 0xA1 -> EEPROM_READ_ADRESS1
	r=i2cRead(0); i2cStop();
	return r;
}
void eepromWrite(int adr, unsigned char data)
{
	if (!i2cStart(EEPROM_READ_ADRESS0)) uartSendS("No ack!"); //dummy write // B: 0xA0 -> EEPROM_READ_ADRESS0
	i2cWrite(adr); i2cWrite(data); i2cStop();
}
unsigned int rtlRead(int addr)
{
	unsigned int r;
	setScl(0); setScl(1); setScl(0);
	if (!i2cStart(RTL_READ_ADRESS)) uartSendS("No ack!"); //rtl read		// B: 0xA9 -> RTL_READ_ADRESS
	i2cWrite(addr & 0xff); i2cWrite(addr>>8);
	r = i2cRead(1); r |= (i2cRead(0)<<8);
	i2cStop();
	setScl(0); setScl(1); setScl(0);
	return r;
}
void rtlWrite(int addr, int data)
{
	setScl(0); setScl(1); setScl(0);
	if (!i2cStart(RTL_WRITE_ADRESS)) uartSendS("No ack!"); //rtl read		// B: 0xA8 -> RTL_WRITE_ADRESS
	i2cWrite(addr & 0xff); i2cWrite(addr>>8);
	i2cWrite(data & 0xff); i2cWrite(data>>8);
	i2cStop();
	setScl(0); setScl(1); setScl(0);
}
//Init all io-ports
void initIo(void)
{
//	TWBR = 120; //50KHz
	i2cStop();
/*  for (int x = 0; x < 256; x += 2)
	{
		printf("\n %x: ", x);
		if (!i2cStart(x + 1)) printf("No ack!"); //rtl read
		else                  i2cRead(0);
		i2cStop(); i2cStop();
//		_delay_ms(1000);
	}
	getchar(); */
}
#if 0
//Original i2c routines, using the TWI module. That one refuses to do any writes when the first byte you send
//has the 'read'-bit set, which won't work with the Realtek chip.
#include <util/twi.h>

static void twWait(int pos)
{
	int n = 0;
	while((!(TWCR & (1<<TWINT))) && n != 1000)
	{
		_delay_ms(2);
		n++;
	}
	if (n == 1000)
	{
		printf("TWI timeout at %i.", pos);
		TWCR = 0;
		TWCR = (1<<TWINT) | (1<<TWSTO) | (1<<TWEN);
	}
}
static char i2cStart(char address)
{
	TWCR = (1<<TWINT) | (1<<TWSTA) | (1<<TWEN);
	twWait(1);
	TWDR = address;
	TWCR = (1<<TWINT) | (1<<TWEN);
	twWait(2);
	if ((TWSR & 0xF8) != TW_MT_SLA_ACK && (TWSR & 0xF8) != TW_MR_SLA_ACK) return 0;
	return 1;
}
static void i2cStop(void)
{
	TWCR = (1<<TWINT) | (1<<TWSTO) | (1<<TWEN);
//	twWait(3);
}
static char i2cWrite(unsigned char data)
{
	TWDR = data;
	TWCR = (1<<TWINT) | (1<<TWEN);
	twWait(4);
	if ((TWSR & 0xF8) != TW_MT_DATA_ACK) return 0;
	return 1;
}
static unsigned char i2cRead(char ack)
{
	unsigned char c;
//	TWDR = 0;
	PORTC = 0;
	if (ack) TWCR = (1<<TWINT) | (1<<TWEN) | (1<<TWEA);
	else TWCR = (1<<TWINT) | (1<<TWEN);
	twWait(5);
	c = TWDR;
	return c;
}
#endif
