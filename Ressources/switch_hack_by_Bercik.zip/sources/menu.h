#ifndef _MENU_H  // B: for no multi added header files
#define _MENU_H  //

#include <avr/pgmspace.h>

int menuShow(PGM_P menuString, void (getData)(uint8_t menuItem, uint8_t no, char* buff));	// B: 2x int -> uint8_t

#endif			 // ifndef _MENU_H
