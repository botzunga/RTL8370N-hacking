Use these fuse values: low=0xFD, high=0xD5, extended=0xF9
The serial port works at 19200,8,n,1 with a 6MHz crystal.

Modification by Bercik January 2014 (C):
- all of the changes what i have made were signed by comment lines: "// B: "
- i do not change anything what is switched off by pre-processor or by Jeroen
- there are some fixes for smaller hex-file after compiling (int -> uint8_t)
- uC works with 8MHz internal RC, UART works with parameters as above, new fuses are: low=0xC2, high=0xD5, extended=0x01
- routines to send chars with "printf_P" are changed to routines with directly operations on Atmega UART registers
- changed startup lines "...." with countdown
- fixed for selecting port stricty in range 1-5 and vid in range 1-4096
- switched off includes that are not needed
- added command for switch off not used ATMega components
- added function to read Realtek chip name and chip version
- added function to switch on Ingress for "bad vid member"
- added function to shows/saves only five vid from/to RTL table and from/to AVR EEPROM. Tested with 67B.
  In the preprocessor it is named: MIN_SHOW_VID. When you add vid to port, programm will remove membership of previous vid
  and add untagged membership with this port to new vid
- optimalization for compiler:
  -fpack-struct -fshort-enums -ffunction-sections -mshort-calls -mcall-prologues -mrelax -mstrict-X -mno-interrupts -mtiny-stack
  -fdata-sections -funsigned-char -funsigned-bitfields
  gives:
         m88(p)
  : 66RB 5264
  : 67B  5304