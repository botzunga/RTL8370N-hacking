/* Firmware to manage the 'hidden' functions of a RTL8366CB GBit switch.
(C) 2010 Jeroen Domburg (jeroen AT spritesmods.com)
(C) Bercik (ro_beri AT gazeta.pl)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.
	    
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
			    
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.*/

//This file provides stdin and stdout over the UART to the rest of the program.
#include <avr/io.h>
#include <avr/pgmspace.h>	  // B: added header file for pgm_read_byte
//#include <avr/sleep.h>	  // B: not needed header files in stdout.c
//#include <avr/interrupt.h>  // B: not needed header files in stdout.c
//#include <util/delay.h>	  // B: not needed header files in stdout.c
//#include <stdio.h>		  // B: not needed when using uart_send/uart_get
#include "stdout.h"			  // B: added header file

/*  B: not needed when using uart_send and uart_get
static int uart_putchar(char c, FILE *stream)
{
    if (c == '\n') uart_putchar('\r', stream);
    while( !(UCSR0A & (1<<UDRE0)) );    // B: changed to name /UCSR0A & 0x20/
    UDR0 = c;
    return 0;
}
static int uart_getchar(FILE *stream)
{
	unsigned char c;
	while( !(UCSR0A & (1<<RXC0)) );     // B: changed to name /UCSR0A & 0x80/
    c = UDR0;
	if (c == '\r') return '\n';
    return c;
}
static FILE mystdout = FDEV_SETUP_STREAM(uart_putchar, NULL, _FDEV_SETUP_WRITE);
static FILE mystdin = FDEV_SETUP_STREAM(NULL, uart_getchar, _FDEV_SETUP_READ);
*/
void stdoutInit(uint8_t ubr)			// B: int -> uint8_t
{
	UCSR0B |= (1<<TXEN0) | (1<<RXEN0);  // B: changed to name /UCSR0B = 0x18;/
	UBRR0L = ubr;						// B: when ubr < 256 /UBRR0L = ubr & 0xff;/
    //UBRR0H = ubr>>8;					// B: not nedded when ubr < 256
	//stdout = &mystdout;				// B: not needed when using uart_send
	//stdin = &mystdin;					// B: not needed when using uart_get
}
void uartSend(uint8_t data)				// B: sends one char without "printf"
{
	if (data == '\n') uartSend('\r');
	while ( !(UCSR0A & (1<<UDRE0)) );
	UDR0 = data;
}
void uartSendS(char *s)					// B: sends string without "printf"
{
	register char c;
	while ((c = *s++)) uartSend(c);
}
void uartSends_P(const char *s)			// B: sends string_P without "printf"
{
	register char c;
	while ((c = pgm_read_byte(s++))) uartSend(c);
}
char uartGet(void)						// B: receive char without "printf"
{
	while( !(UCSR0A & (1<<RXC0)) );
    return UDR0;
}
