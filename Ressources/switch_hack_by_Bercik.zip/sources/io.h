#ifndef _IO_H  // B: for non multi added header files
#define _IO_H  //

//This program is licensed under the GPLv3; see license.txt for more info.
//Copyright 2007 Sprite_tm
//Copyright 2014 Bercik

#define RTL8366RB 1			// B: Here is definition for preprocesor compiling to selected proper Realtek chip
#define RTL8367   2			// B: Not ready for RTL8367
#define RTL8367B  3

#define CHIP RTL8366RB		// B: Here select proper Realtek chip

#if CHIP == 1 || CHIP == 2 || CHIP == 3
	#define PORT_COUNT 5	// B: Here select number of ports in switch. For 66RB, 67, 67B it's 5
#else
	#define PORT_COUNT 8
#endif

#define MIN_SHOW_VID 1		// B: Shows/saves only five vid from/to RTL table and from/to AVR EEPROM. Tested with 67B

unsigned char eepromRead(int adr);
void eepromWrite(int adr, unsigned char data);
unsigned int rtlRead(int addr);
void rtlWrite(int addr, int data);
void initIo(void);

#endif			// ifndef _IO_H
